// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'simon',
        'password': 'pass'
    },
	'database': 'nodedb1',
    'users_table': 'usersignup'
};
